import React, { useEffect, useMemo, useRef, useState } from "react";

const LS_KEY = "pagalo.payments.v1";

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}
function startOfDay(d) { const x = new Date(d); x.setHours(0,0,0,0); return x; }
function daysBetween(a,b){ const ms = startOfDay(b) - startOfDay(a); return Math.round(ms/86400000); }
function addDays(d,n){ const x = new Date(d); x.setDate(x.getDate()+n); return x; }
function nextRecurringDate(dateStr, rule){
  const d = new Date(dateStr); const now = new Date();
  if (rule === "none") return d;
  let next = new Date(d);
  while (next < startOfDay(now)) {
    if (rule === "weekly") next = addDays(next,7);
    else if (rule === "monthly") { const m = new Date(next); m.setMonth(m.getMonth()+1); next = m; }
    else if (rule === "yearly") { const y = new Date(next); y.setFullYear(y.getFullYear()+1); next = y; }
    else break;
  }
  return next;
}

const typeEmojis = { electricity:"💡", internet:"🌐", phone:"📱", rent:"🏠", card:"💳", water:"🚰", streaming:"🎬", other:"🧾" };

export default function App(){
  const [items, setItems] = useState(()=>{
    try{ const raw = localStorage.getItem(LS_KEY); return raw? JSON.parse(raw): [] } catch{ return [] }
  });
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("upcoming");
  const [notifEnabled, setNotifEnabled] = useState(false);

  useEffect(()=>{ localStorage.setItem(LS_KEY, JSON.stringify(items)); }, [items]);

  useEffect(()=>{
    if(!notifEnabled) return;
    if(!("Notification" in window)) return;
    if(Notification.permission === "default"){ Notification.requestPermission(); }
  }, [notifEnabled]);

  const timersRef = useRef([]);
  useEffect(()=>{
    timersRef.current.forEach(clearTimeout);
    timersRef.current = [];
    if(!notifEnabled || !("Notification" in window) || Notification.permission !== "granted") return;
    const schedule = (title, whenMs) => {
      if (whenMs <= 0) return;
      const id = setTimeout(()=>{ try{ new Notification("Págalo", { body: title }) } catch{} }, whenMs);
      timersRef.current.push(id);
    };
    const now = Date.now();
    items.filter(i=>!i.paid).forEach(i=>{
      const due = new Date(i.dueAt).getTime();
      const three = due - 3*86400000 - now;
      const one = due - 86400000 - now;
      const same = due - now;
      const title = `${i.icon || ""} ${i.name} vence ${new Date(i.dueAt).toLocaleDateString()}`;
      schedule(title, three); schedule(title, one); schedule(title, same);
    });
  }, [items, notifEnabled]);

  const today = startOfDay(new Date());
  const computed = useMemo(()=>{
    const mapped = items.map(i=>{
      const dueDate = nextRecurringDate(i.dueAt, i.repeat);
      const diff = daysBetween(today, dueDate);
      let status = "due"; if (i.paid) status = "paid"; else if (diff < 0) status = "overdue";
      return { ...i, dueDate, daysLeft: diff, status };
    });
    const filtered = mapped.filter(i=>{
      const matches = [i.name, i.note, i.type].join(" ").toLowerCase().includes(query.toLowerCase());
      if(!matches) return false;
      if (filter === "all") return true;
      return i.status === (filter === "upcoming" ? "due" : filter);
    });
    const weeklyNeed = mapped.filter(i=>!i.paid && i.daysLeft >= 0 && i.daysLeft <= 7)
      .reduce((s,i)=> s + Number(i.amount||0), 0);
    return { mapped, filtered, weeklyNeed };
  }, [items, query, filter]);

  return (
    <div className="container">
      <header className="header">
        <div>
          <h1 className="title">Págalo</h1>
          <p className="subtitle">Que no se te pase ni un pago más.</p>
        </div>
        <div style={{display:"flex", gap:8}}>
          <button className="btn" onClick={()=>setShowForm(true)}>➕ Añadir pago</button>
          <ShareMenu items={computed.mapped}/>
          <BackupMenu items={items} setItems={setItems}/>
        </div>
      </header>

      <Summary weeklyNeed={computed.weeklyNeed} items={computed.mapped}
        notifEnabled={notifEnabled} setNotifEnabled={setNotifEnabled} />

      <Toolbar query={query} setQuery={setQuery} filter={filter} setFilter={setFilter} />

      <div className="grid">
        {computed.filtered.sort((a,b)=>a.dueDate-b.dueDate).map(i=>(
          <PaymentCard key={i.id} item={i}
            onEdit={()=>{ setEditing(i); setShowForm(true); }}
            onTogglePaid={()=>togglePaid(i, setItems)}
            onDelete={()=>removeItem(i, setItems)}
          />
        ))}
      </div>

      {showForm && (
        <PaymentForm
          onClose={()=>{ setShowForm(false); setEditing(null); }}
          onSave={(data)=>{
            if (editing) setItems(prev=>prev.map(p=> p.id===editing.id? {...editing, ...data}: p));
            else setItems(prev=> [{ id: uid(), paid:false, ...data }, ...prev]);
            setShowForm(false); setEditing(null);
          }}
          initial={editing}
        />
      )}

      <footer><p>Hecho con ❤️ · MVP PWA</p></footer>
    </div>
  );
}

function Summary({ weeklyNeed, items, notifEnabled, setNotifEnabled }) {
  const totalMonth = useMemo(()=> items.filter(i=>!i.paid && i.daysLeft >= 0 && i.daysLeft <= 31)
      .reduce((s,i)=> s + Number(i.amount||0), 0), [items]);
  const overdue = items.filter(i=> i.status === "overdue").length;
  return (
    <div className="summary">
      <div className="tile">
        <div>💰</div>
        <div><div style={{color:"#64748b", fontSize:13}}>Necesitas esta semana</div>
        <div style={{fontWeight:800, fontSize:22}}>$ {weeklyNeed.toLocaleString()}</div></div>
      </div>
      <div className="tile">
        <div>🗓️</div>
        <div><div style={{color:"#64748b", fontSize:13}}>Pagos del mes (restantes)</div>
        <div style={{fontWeight:800, fontSize:22}}>$ {totalMonth.toLocaleString()}</div></div>
      </div>
      <div className="tile">
        <div>⚠️</div>
        <div><div style={{color:"#64748b", fontSize:13}}>Atrasados</div>
        <div style={{fontWeight:800, fontSize:22}}>{overdue}</div></div>
      </div>
      <label className="tile switch">
        <input type="checkbox" checked={notifEnabled} onChange={e=>setNotifEnabled(e.target.checked)} />
        <span>🔔 Notificaciones</span>
      </label>
    </div>
  );
}

function Toolbar({ query, setQuery, filter, setFilter }) {
  return (
    <div className="toolbar">
      <input placeholder="Buscar pago, nota o tipo…" value={query} onChange={e=>setQuery(e.target.value)} />
      <select value={filter} onChange={e=>setFilter(e.target.value)}>
        <option value="upcoming">Próximos</option>
        <option value="overdue">Atrasados</option>
        <option value="paid">Pagados</option>
        <option value="all">Todos</option>
      </select>
    </div>
  );
}

function PaymentCard({ item, onEdit, onTogglePaid, onDelete }) {
  const days = item.daysLeft;
  const statusText = item.paid ? "Pagado" : days < 0 ? `Vencido hace ${Math.abs(days)} d` : days === 0 ? "Vence hoy" : `En ${days} d`;
  const badgeClass = item.paid ? "green" : (days < 0 ? "red" : "yellow");
  return (
    <div className="card">
      <div className="card-header">
        <div className="card-title"><span style={{fontSize:22}}>{item.icon || typeEmojis[item.type] || "🧾"}</span>{item.name}</div>
        <span className={"badge " + badgeClass}>{statusText}</span>
      </div>
      <div className="card-content">
        <div className="row"><span>Monto</span><strong>$ {Number(item.amount).toLocaleString()}</strong></div>
        <div className="row"><span>Vence</span><strong>{new Date(item.dueDate).toLocaleDateString()}</strong></div>
        <div className="row"><span>Repite</span><strong>
          {item.repeat==="none" && "No"}
          {item.repeat==="weekly" && "Semanal"}
          {item.repeat==="monthly" && "Mensual"}
          {item.repeat==="yearly" && "Anual"}
        </strong></div>
        {item.note && <div className="row" style={{display:"block", color:"#64748b", fontSize:13, borderTop:"1px solid #f1f5f9", paddingTop:8}}>{item.note}</div>}
        <div style={{display:"flex", gap:8, justifyContent:"flex-end", marginTop:8}}>
          <button className="btn secondary" onClick={onEdit}>✏️ Editar</button>
          <button className="btn" onClick={onTogglePaid}>{item.paid ? "🔁 Marcar pendiente" : "✅ Marcar pagado"}</button>
          <button className="btn danger" onClick={onDelete}>🗑️ Borrar</button>
        </div>
      </div>
    </div>
  );
}

function togglePaid(item, setItems) {
  setItems(prev => prev.map(p=>{
    if (p.id !== item.id) return p;
    if (!p.paid) {
      const next = nextRecurringDate(p.dueAt, p.repeat);
      const advance = p.repeat === "weekly" ? 7 : p.repeat === "monthly" ? 30 : 365;
      const after = p.repeat === "none" ? p.dueAt : new Date(next.getTime() + advance*86400000).toISOString();
      return { ...p, paid: true, dueAt: after };
    } else {
      return { ...p, paid: false };
    }
  }));
}
function removeItem(item, setItems){ setItems(prev=> prev.filter(p=>p.id !== item.id)); }

function PaymentForm({ onClose, onSave, initial }) {
  const [name, setName] = useState(initial?.name || "");
  const [amount, setAmount] = useState(initial?.amount || "");
  const [dueAt, setDueAt] = useState(initial ? new Date(initial.dueAt).toISOString().slice(0,10) : new Date().toISOString().slice(0,10));
  const [type, setType] = useState(initial?.type || "other");
  const [repeat, setRepeat] = useState(initial?.repeat || "monthly");
  const [note, setNote] = useState(initial?.note || "");
  const [icon, setIcon] = useState(initial?.icon || "");

  const onSubmit = (e) => {
    e.preventDefault();
    onSave({ name, amount: Number(amount||0), dueAt: new Date(dueAt).toISOString(), type, repeat, note, icon });
  };

  return (
    <div className="dialog" role="dialog" aria-modal="true">
      <form className="panel" onSubmit={onSubmit}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <h2>{initial? "Editar pago" : "Nuevo pago"}</h2>
          <button type="button" className="btn outline" onClick={onClose}>✖</button>
        </div>
        <div className="grid">
          <div><label>Nombre</label><input required value={name} onChange={e=>setName(e.target.value)} placeholder="Luz, Internet, Alquiler…"/></div>
          <div><label>Monto</label><input required type="number" min="0" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="0"/></div>
          <div><label>Fecha de vencimiento</label><input required type="date" value={dueAt} onChange={e=>setDueAt(e.target.value)}/></div>
          <div><label>Repetición</label>
            <select value={repeat} onChange={e=>setRepeat(e.target.value)}>
              <option value="none">No repetir</option>
              <option value="weekly">Semanal</option>
              <option value="monthly">Mensual</option>
              <option value="yearly">Anual</option>
            </select>
          </div>
          <div><label>Tipo</label>
            <select value={type} onChange={e=>setType(e.target.value)}>
              <option value="electricity">Luz</option>
              <option value="internet">Internet</option>
              <option value="phone">Celular</option>
              <option value="rent">Alquiler</option>
              <option value="card">Tarjeta</option>
              <option value="water">Agua</option>
              <option value="streaming">Streaming</option>
              <option value="other">Otro</option>
            </select>
          </div>
          <div><label>Ícono (opcional)</label><input value={icon} onChange={e=>setIcon(e.target.value)} placeholder="Ej: 💡, 📶, 🏠"/></div>
        </div>
        <div><label>Nota</label><textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Referencia, cuenta, último dígito, etc."></textarea></div>
        <div style={{display:"flex",justifyContent:"flex-end",gap:8}}>
          <button type="button" className="btn secondary" onClick={onClose}>Cancelar</button>
          <button type="submit" className="btn">🔔 Guardar</button>
        </div>
      </form>
    </div>
  );
}

function ShareMenu({ items }){
  const share = async () => {
    const upcoming = items.filter(i=>!i.paid && i.daysLeft >= 0).sort((a,b)=>a.dueDate-b.dueDate).slice(0,10)
      .map(i=> `• ${i.icon || ""} ${i.name}: $${i.amount} — ${new Date(i.dueDate).toLocaleDateString()}`).join("\n");
    const text = `Próximos pagos:\n${upcoming || "(sin pagos)"}`;
    if (navigator.share) { try{ await navigator.share({ title:"Págalo — Próximos pagos", text }); } catch{} }
    else { await navigator.clipboard.writeText(text); alert("Lista copiada al portapapeles"); }
  };
  return <button className="btn secondary" onClick={share}>📤 Compartir</button>;
}

function BackupMenu({ items, setItems }){
  const fileRef = React.useRef();
  const exportJson = () => {
    const blob = new Blob([JSON.stringify(items,null,2)], { type:"application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `pagalo-backup-${new Date().toISOString().slice(0,10)}.json`; a.click();
    URL.revokeObjectURL(url);
  };
  const importJson = (e) => {
    const file = e.target.files?.[0]; if(!file) return;
    const reader = new FileReader();
    reader.onload = () => { try { const data = JSON.parse(reader.result); if (Array.isArray(data)) setItems(data); } catch{} };
    reader.readAsText(file);
  };
  return (
    <div style={{display:"flex", gap:8}}>
      <button className="btn outline" onClick={exportJson}>⬇️ Exportar</button>
      <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={importJson}/>
      <button className="btn outline" onClick={()=>fileRef.current?.click()}>⬆️ Importar</button>
    </div>
  );
}
